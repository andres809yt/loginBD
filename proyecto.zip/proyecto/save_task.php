            <?php

            include('db.php');

            if (isset($_POST['save_task'])) {
              $email = $_POST['email'];
              $fechadenacimiento = $_POST['fechadenacimiento'];
              $usuario = $_POST['usuario'];
              $contraseña = $_POST['contraseña'];
              
              $query = "INSERT INTO registro (email, fechadenacimiento, usuario, contraseña, ) 
              VALUES ('$email', '$fechadenacimiento', '$usuario', '$contraseña', )";
              $result = mysqli_query($conn, $query);
              if(!$result) {
                die("Query Failed.");
              }

              $_SESSION['message'] = 'Task Saved Successfully';
              $_SESSION['message_type'] = 'success';
              header('Location: index.php');

            }

            ?>