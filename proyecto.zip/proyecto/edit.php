<?php
include("db.php");
  $email ='';
  $fechadenacimiento = '';
  $usuario = '';
  $contraseña = '';

if  (isset($_GET['usuario'])) {
  $IDMedico = $_GET['usuario'];
  $query = "SELECT * FROM registro WHERE usuario=$usuario";
  $result = mysqli_query($conn, $query);
  if (mysqli_num_rows($result) == 1) {
    $row = mysqli_fetch_array($result);
    $email = $row['email'];
    $fechadenacimiento = $row['fechadenacimiento'];
    $usuario = $row['contraseña'];
  
  }
}

if (isset($_POST['update'])) {
  $email = $_GET['email'];
  $fechadenacimiento = $_POST['fechadenacimiento'];
  $usuario = $_POST['usuario'];
  $contraseña = $_POST['contraseña'];
 

  $query = "UPDATE registro 
            SET  = '$Nombre', Email = '$Email', FechaDeNacimiento = '$Nacimiento', Direccion = '$Direccion'
            WHERE usuario=$usuario";
  mysqli_query($conn, $query);
  $_SESSION['message'] = 'usuario Actualizado';
  $_SESSION['message_type'] = 'warning';
  header('Location: index.php');
}

?>
<?php include('includes/header.php'); ?>
<div class="container p-4">
  <div class="row">
    <div class="col-md-4 mx-auto">
      <div class="card card-body">
      <form action="edit.php?IDMedico=<?php echo $_GET['usuario']; ?>" method="POST">
        <div class="form-group">
          <input name="Nombre" type="text" class="form-control" value="<?php echo $Nombre; ?>" placeholder="Actualiza el Nombre">
        </div>
        <div class="form-group">
          <input name="Email" type="text" class="form-control" value="<?php echo $Email; ?>" placeholder="Actualiza el email">
        </div>
        <div class="form-group">
          <input name="FechaDeNacimiento" type="text" class="form-control" value="<?php echo $Nacimiento; ?>" placeholder="Actualiza fecha de nacimiento">
        </div>

        <div class="form-group">
          <input name="Direccion" type="text" class="form-control" value="<?php echo $Direccion; ?>" placeholder="Actualiza dirección">
        </div>
        <button class="btn-success" name="update">
          Actualizar
</button>
      </form>
      </div>
    </div>
  </div>
</div>
<?php include('includes/footer.php'); ?>
